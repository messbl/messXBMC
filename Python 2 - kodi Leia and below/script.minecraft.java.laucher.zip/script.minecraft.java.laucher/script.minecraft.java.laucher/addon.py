import xbmc
import xbmcaddon
import xbmcgui
import os
import subprocess
 
addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')

# Set a string variable to use 
# line1 = "Hello World! We can write anything we want here Using Python"

# Launch a dialog box in kodi showing the string variable 'line1' as the contents
child =subprocess.call("["C:\Program Files (x86)\Minecraft Launcher\MinecraftLauncher.exe"]","-k")
