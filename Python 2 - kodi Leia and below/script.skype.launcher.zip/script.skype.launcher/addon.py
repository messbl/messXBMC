import xbmc
import xbmcaddon
import xbmcgui
import os
import subprocess
child = subprocess.call(["explorer.exe shell:C:\Program Files\WindowsApps\Microsoft.SkypeApp_14.56.102.0x64_kzf8qxf38zg5c\Microsoft.SkypeApp_kzf8qxf38zg5c!SkypeApp.App","-k"])
