import xbmc
import subprocess

child = subprocess.call(["C:\Program Files (x86)\Microsoft Studios\Minecraft Education Edition\Minecraft.Windows.exe","-k"])
