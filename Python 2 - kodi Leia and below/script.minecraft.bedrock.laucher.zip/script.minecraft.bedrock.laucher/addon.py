import xbmc
import xbmcaddon
import xbmcgui
import os
import subprocess
child = subprocess.call(["explorer.exe shell:C:\Program Files\WindowsApps\Microsoft.MinecraftUWP_1.14.3002.0x64_8wekyb3d8bbwe\Microsoft.MinecraftUWP_8wekyb3d8bbwe!Minecraft_Win10.App","-k"])
