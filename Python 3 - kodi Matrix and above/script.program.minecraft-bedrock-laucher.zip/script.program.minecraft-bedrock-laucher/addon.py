import xbmc
import xbmcaddon
import xbmcgui
import os
import subprocess
child = subprocess.call(["explorer.exe","shell:appsfolder\Microsoft.MinecraftUWP_8wekyb3d8bbwe!App"])
