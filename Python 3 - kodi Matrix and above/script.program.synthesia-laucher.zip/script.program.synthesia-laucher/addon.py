import xbmc
import subprocess
 
child = subprocess.call(["C:\Program Files (x86)\Synthesia\Synthesia.exe"])
