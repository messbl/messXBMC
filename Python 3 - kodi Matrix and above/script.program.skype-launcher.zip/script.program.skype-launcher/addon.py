import xbmc
import xbmcaddon
import xbmcgui
import os
import subprocess
child = subprocess.call(["explorer.exe","shell:appsfolder\Microsoft.SkypeApp_kzf8qxf38zg5c!App"])
