import os
import xbmc
import subprocess

child = subprocess.call(["C:\Users\Rozrywka\AppData\Local\WhatsApp\WhatsApp.exe","-k"])
